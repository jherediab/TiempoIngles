package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.Query;

//import org.apache.log4j.Logger;

//import com.ssl.jv.gip.jpa.pojo.Ubicacion;
//import com.ssl.jv.gip.negocio.dto.UbicacionRecibirDevolucionDTO;







import com.journaldev.jsf.util.DataConnect;

import dto.TiempoDTO;

@Stateless
@LocalBean
public class TiempoDao 
{
//extends GenericDAO<Ubicacion> implements UbicacionDAOLocal {
  //private static final Logger LOGGER = Logger.getLogger(UbicacionDao.class);
	
	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;

  public TiempoDao() {
  
  	
  	conn = DataConnect.getConnection();
  }


  
  public List<TiempoDTO> consultar() {
    List<TiempoDTO> lista = new ArrayList<TiempoDTO>();
    try {
      String sql = "SELECT id , num from tiempo" ;
      
      pstmt = conn.prepareStatement(sql);
      rs = pstmt.executeQuery();
      
      //List<Object[]> listado = em.createNativeQuery(sql).getResultList();
      //if (listado != null) {
      
      System.out.println("Reporte1:"+sql);
      while(rs.next()){
      
        //for (Object[] objs : listado) {
        	TiempoDTO dto = new TiempoDTO();
          dto.setId(rs.getLong(1));
          dto.setNum(rs.getString(2));
          lista.add(dto);
        //}
      //}
      }
      	
    }
    catch (SQLException e) {
			System.out.println(e.getMessage());
			
			
		}	
    
    
  	finally {

			try {
				conn.close();
				pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
    
    
   
    
    return lista;
  }

  }

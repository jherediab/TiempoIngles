package dto;

public class TiempoDTO {
	
	
	private Long Id;

	private String Num;

	public Long getId() {
		return Id;
	}

	public void setId(Long id) {
		Id = id;
	}

	public String getNum() {
		return Num;
	}

	public void setNum(String num) {
		Num = num;
	}
	


}

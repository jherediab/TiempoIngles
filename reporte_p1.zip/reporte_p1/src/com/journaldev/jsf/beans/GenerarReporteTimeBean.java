package com.journaldev.jsf.beans;



import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Named;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;




import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;

























import dao.TiempoDao;
import dto.TiempoDTO;






import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.io.OutputStreamWriter;
import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.io.OutputStream;



















import java.nio.charset.Charset;





















import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;








@ManagedBean (name = "generarArchivoConfirmingBean")
@Named
@RequestScoped
public class GenerarReporteTimeBean implements Serializable  {
	
	
	private Date date15;
	
	
	  private int hora;
	  
	  private int minuto;
	
	 private Date minTime;
	 private Date maxTime;
	
	private StreamedContent reporte;
	private Date fechaInicial;
	private Date fechaFinal;


	private HashMap hm ;

  private static final long serialVersionUID = 288560933970701674L;

	
  @PostConstruct
  public void init() {
  	
  	
  	    
     
     //obtenerListaAlmacen();
     
     
     System.out.println("ingreso a Generar Time");
     
     
     
  }


  
  public Date getDate15() {
      return date15;
  }

  public void setDate15(Date date15) {
      this.date15 = date15;
  }

  

  public Date getMinTime() {
      return minTime;
  }

  public void setMinTime(Date minTime) {
      this.minTime = minTime;
  }

  
  public Date getMaxTime() {
      return maxTime;
  }

  public void setMaxTime(Date maxTime) {
      this.maxTime = maxTime;
  }

  
	public Date getFechaFinal() {
		return fechaFinal;
	}



	public void setFechaFinal(Date fechaFinal) {
		this.fechaFinal = fechaFinal;
	}



	public Date getFechaInicial() {
		return fechaInicial;
	}



	public void setFechaInicial(Date fechaInicial) {
		this.fechaInicial = fechaInicial;
	}

	
	public void mostrarRelatorio(byte[] relatorio, HttpServletResponse response,String orden){
		try {
			ServletOutputStream out = response.getOutputStream();
			//response.setContentType("application/pdf","ReporteVentas.pdf");
			String filename=orden+"reporteVentas_";
			
			response.setHeader("Content-Disposition","inline; filename=" + filename + ".pdf" );
			out.write(relatorio);
			
			
			

			
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
	}




	

	
	
	  
   
    public void convertir() 
    { 
    	
    	
    	
    	
    	String mensaje="";
    	
    	 
    	
        String nums[] = { "zero", "one", "two", "three", "four", 
                            "five", "six", "seven", "eight", "nine", 
                            "ten", "eleven", "twelve", "thirteen", 
                            "fourteen", "fifteen", "sixteen", "seventeen", 
                            "eighteen", "nineteen", "twenty", "twenty one", 
                            "twenty two", "twenty three", "twenty four", 
                            "twenty five", "twenty six", "twenty seven", 
                            "twenty eight", "twenty nine", 
                        }; 
        
        
       
        
        
  
      
        if (minuto == 0) 
            //System.out.println(nums[hora] + " o' clock "); 
        	mensaje=nums[hora] + " o' clock ";
      
        else if (minuto  == 1) 
            //System.out.println("one minute past " +  nums[hora]); 
        mensaje="one minute past " +  nums[hora];
      
        else if (minuto  == 59) 
            //System.out.println("one minute to " + nums[(hora % 12) + 1]); 
        
        mensaje="one minute to " +  nums[(hora % 12) + 1];
      
        else if (minuto  == 15) 
           // System.out.println("quarter past " + nums[hora]); 
        mensaje="quarter past " + nums[hora];
        else if (minuto  == 30) 
            //System.out.println("half past " + nums[hora]); 
        mensaje="half past " + nums[hora];
        else if (minuto  == 45) 
            //System.out.println("quarter to " +  nums[(hora % 12) + 1]); 
        mensaje="quarter to " +  
                nums[(hora % 12) + 1];
      
        else if (minuto  <= 30) 
           // System.out.println( nums[minuto] + " minutes past " + 
                                        //            nums[hora]); 
        mensaje=nums[minuto] + " minutes past " +   nums[hora];
      
        else if (minuto  > 30) 
            //System.out.println( nums[60 - minuto] + " minutes to " +      
                                             //   nums[(hora % 12) + 1]); 
        mensaje= nums[60 - minuto] + " minutes to " +      
                nums[(hora % 12) + 1];
        
        
        
        
        addMessage("Hora en ingles en palabras: "+ mensaje);
    } 
      




    public void addMessage(String summary) {
        FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, summary, null);
        FacesContext.getCurrentInstance().addMessage(null, message);
    }
	



  



	
	
	
  












  




public StreamedContent getcrearArchivoPlano()
{

	System.out.println("ingreso a crearArchivoPlano");
	//Date fechaInicial = null;

	java.util.Date fecha = new Date();
	
	SimpleDateFormat ft = new SimpleDateFormat("ddMMMyyyy");
  String dateInicial = ft.format(fecha);
	
  //List<String> command = new ArrayList<String>();
  StreamedContent reporte = null;
  //boolean ASC = true;
  
  
  

  
  
  StringBuilder builder = new StringBuilder();
      
         //Whatever the file path is.
         //File statText = new File("C:\\Reportes_FacturaTxt\\factura.txt");
         

        // FileOutputStream fos=new FileOutputStream("outputOne.txt");
        //ObjectOutputStream output=new ObjectOutputStream(fos);  
         
         //FileOutputStream is = new FileOutputStream(statText);
         //OutputStreamWriter osw = new OutputStreamWriter(is);    
         //BufferedWriter  w = new BufferedWriter(osw);
  
  
  System.out.println("tamano archivo2"+hm.size());
  
  
  
  
  
  
  

         
         //Iterator iter = hm.entrySet().iterator();
       	//while (iter.hasNext()) {
       		//Map.Entry entry = (Map.Entry) iter.next();
       		//System.out.println("[Key] : " + entry.getKey() + " [Cantidad] : " + ((facturaBean) entry.getValue()).getFactura()+ " [valor] : " + ((facturaBean) entry.getValue()).getNit());
//       		 w.append(((FacturaBean) entry.getValue()).getNit()+"\t"+((FacturaBean) entry.getValue()).getFactura()+"\t"+((FacturaBean) entry.getValue()).getFecha_emision()
//       				 +"\t"+((FacturaBean) entry.getValue()).getFecha_vencimiento()+"\t"+"N/A"+"\t"+((FacturaBean) entry.getValue()).getFecha_pago()
//       				 +"\t"+((FacturaBean) entry.getValue()).getValor()+"\t"+((FacturaBean) entry.getValue()).getValor()+"\t"+((FacturaBean) entry.getValue()).getDeudor()
//       				 +"\t"+"N/A"+"\t"+"N/A"+"\t"+"N/A"+"\t"+"I"+"\t"+"F"+"NA"
//       				 );
//       		 w.newLine();
       		
       		
      //	}
       	
       	

       
       	
       
        
     //   System.out.println("tamano archivo arraylist"+command.size());
       	String result = builder.toString();
     
      
				return reporte;
        
        
      
      
}



public int getHora() {
	return hora;
}



public void setHora(int hora) {
	this.hora = hora;
}



public int getMinuto() {
	return minuto;
}



public void setMinuto(int minuto) {
	this.minuto = minuto;
}       




   

}



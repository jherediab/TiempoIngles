package com.journaldev.jsf.beans;



import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Named;




import dao.TiempoDao;
import dto.TiempoDTO;

import java.io.Serializable;







@ManagedBean (name = "generarArchivoConfirmingBean")
@Named
@RequestScoped
public class GenerarReporteTimeBean implements Serializable  {
	
	
	
	
	
	  private int hora;
	  
	  private int minuto;
	

	


  private static final long serialVersionUID = 288560933970701674L;

	
  @PostConstruct
  public void init() {
  	
  	
  	    
     

     
     
     System.out.println("ingreso a Generar Time");
     
     
     
  }






	

	
	
	  
   
    public void convertir() 
    { 
    	
    	
    	
    	
    	String mensaje="";
    	
    	 
    	
        String nums[] = { "zero", "one", "two", "three", "four", 
                            "five", "six", "seven", "eight", "nine", 
                            "ten", "eleven", "twelve", "thirteen", 
                            "fourteen", "fifteen", "sixteen", "seventeen", 
                            "eighteen", "nineteen", "twenty", "twenty one", 
                            "twenty two", "twenty three", "twenty four", 
                            "twenty five", "twenty six", "twenty seven", 
                            "twenty eight", "twenty nine", 
                        }; 
        
        
       
        
        
  
      
        if (minuto == 0) 
            //System.out.println(nums[hora] + " o' clock "); 
        	mensaje=nums[hora] + " o' clock ";
      
        else if (minuto  == 1) 
            //System.out.println("one minute past " +  nums[hora]); 
        mensaje="one minute past " +  nums[hora];
      
        else if (minuto  == 59) 
            //System.out.println("one minute to " + nums[(hora % 12) + 1]); 
        
        mensaje="one minute to " +  nums[(hora % 12) + 1];
      
        else if (minuto  == 15) 
           // System.out.println("quarter past " + nums[hora]); 
        mensaje="quarter past " + nums[hora];
        else if (minuto  == 30) 
            //System.out.println("half past " + nums[hora]); 
        mensaje="half past " + nums[hora];
        else if (minuto  == 45) 
            //System.out.println("quarter to " +  nums[(hora % 12) + 1]); 
        mensaje="quarter to " +  
                nums[(hora % 12) + 1];
      
        else if (minuto  <= 30) 
           // System.out.println( nums[minuto] + " minutes past " + 
                                        //            nums[hora]); 
        mensaje=nums[minuto] + " minutes past " +   nums[hora];
      
        else if (minuto  > 30) 
            //System.out.println( nums[60 - minuto] + " minutes to " +      
                                             //   nums[(hora % 12) + 1]); 
        mensaje= nums[60 - minuto] + " minutes to " +      
                nums[(hora % 12) + 1];
        
        
        
        
        addMessage("Hora en ingles en palabras: "+ mensaje);
    } 
      




    public void addMessage(String summary) {
        FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, summary, null);
        FacesContext.getCurrentInstance().addMessage(null, message);
    }
	







public int getHora() {
	return hora;
}



public void setHora(int hora) {
	this.hora = hora;
}



public int getMinuto() {
	return minuto;
}



public void setMinuto(int minuto) {
	this.minuto = minuto;
}       




   

}


